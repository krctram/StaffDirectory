declare const styles: {
    container: string;
    content: string;
    pivotItem: string;
    learnMoreLink: string;
    serializedTextArea: string;
};
export default styles;
//# sourceMappingURL=SerializedCanvasView.module.scss.d.ts.map