declare const styles: {
    mobilePreviewURLbar: string;
    mobilePreviewTextfield: string;
    mobilePreviewURLbutton: string;
};
export default styles;
//# sourceMappingURL=MobilePreviewURLEntry.module.scss.d.ts.map