declare interface IStaffdirectoryWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'StaffdirectoryWebPartStrings' {
  const strings: IStaffdirectoryWebPartStrings;
  export = strings;
}
