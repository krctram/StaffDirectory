/* tslint:disable */
require("./StaffdirectoryWebPart.module.css");
const styles = {
  staffdirectory: 'staffdirectory_e68b5ca5',
  container: 'container_e68b5ca5',
  row: 'row_e68b5ca5',
  column: 'column_e68b5ca5',
  'ms-Grid': 'ms-Grid_e68b5ca5',
  title: 'title_e68b5ca5',
  subTitle: 'subTitle_e68b5ca5',
  description: 'description_e68b5ca5',
  button: 'button_e68b5ca5',
  label: 'label_e68b5ca5'
};

export default styles;
/* tslint:enable */